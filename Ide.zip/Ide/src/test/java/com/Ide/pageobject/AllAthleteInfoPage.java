package com.Ide.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllAthleteInfoPage {

WebDriver ldriver;
	
	//constructor
	public AllAthleteInfoPage(WebDriver rdriver)
	{
		this.ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//identify webelements	
	//@FindBy(xpath="")
	//Webelement 
	
	//Action On WebElement
	
	public String getPageTitle()
	{
		return(ldriver.getTitle());
	}
}
