package com.Ide.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ExploreAthletesPage {

	WebDriver ldriver;
	
	//constructor
    public 	ExploreAthletesPage(WebDriver rdriver)
    {
    	rdriver=ldriver;
    	PageFactory.initElements(rdriver, this);
    }
    
    //Identify WebElement
    
    @FindBy(xpath="(//div[@class=\"row align-items-center\"])[2]")
    WebElement clickOnName;
    
    
    //Action On WebElement
    
    public void getClickOnName()
    {
    	clickOnName.click();
    }
	
}
