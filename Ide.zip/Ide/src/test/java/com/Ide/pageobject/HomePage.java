package com.Ide.pageobject;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver ldriver;
	
	//constructor
	public HomePage(WebDriver rdriver)
	{
		this.ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//identify webelements
	
	@FindBy(xpath="//ol[@class=\"list-numbered\"]")
	WebElement text;
	
	@FindBy(xpath="(//input[@class=\"form-control SearchAthList\"])[1]")
	WebElement textName;
	
	@FindBy(xpath="//button[@class=\"d-none d-md-block btn btn-primary h-100\"]")
		WebElement clickOnSearch;
		
	//Action on WebElement	
	public String getAllText()
	{
	  String allText=text.getText();
	    return allText;
	}
	
	public void getSearchName(String name)
	{
		textName.sendKeys(name);				
	}
	
	public void getclickOnSearch()
	{
		clickOnSearch.click();
	}
	
	public String getPageTitle()
	{
		return(ldriver.getTitle());
	}
}
